This directory intentionally left empty.  The Feature Pack plugin barfs if there is no content 
directory.  But Git won't save an empty directory.  Thus, we need this readme file.